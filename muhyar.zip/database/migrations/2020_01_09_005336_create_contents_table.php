<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateContentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contents', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('cover');
            $table->integer('user_id');
            $table->string('title');
            $table->string('series_link');
            $table->text('text');
            $table->string('image');
            $table->string('ratio');
            $table->text('text1')->nullable();
            $table->string('image1');
            $table->string('ratio1');
            $table->text('text2')->nullable();
            $table->string('image2');
            $table->string('ratio2');
            $table->text('text3')->nullable();
            $table->string('image3');
            $table->string('ratio3');
            $table->text('text4')->nullable();
            $table->string('image4');
            $table->string('ratio4');
            $table->text('text5')->nullable();
            $table->string('image5');
            $table->string('ratio5');
            $table->text('text6')->nullable();
            $table->string('image6');
            $table->string('ratio6');
            $table->text('text7')->nullable();
            $table->string('image7');
            $table->string('ratio7');
            $table->text('text8')->nullable();
            $table->string('image8');
            $table->string('ratio8');
            $table->text('text9')->nullable();
            $table->string('image9');
            $table->string('ratio9');
            $table->text('text10')->nullable();
            $table->string('image10');
            $table->string('ratio10');
            $table->string('fbappid');
            $table->string('status');
            $table->string('slug');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contents');
    }
}
