<?php

namespace App;

use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Model;

class Content extends Model
{
    use Sluggable;

    protected $fillable = [
        'user_id', 'cover', 'series_link',
        'text', 'image', 'ratio',
        'text1', 'image1', 'ratio1',
        'text2', 'image2', 'ratio2',
        'text3', 'image3', 'ratio3',
        'text4', 'image4', 'ratio4',
        'text5', 'image5', 'ratio5',
        'text6', 'image6', 'ratio6',
        'text7', 'image7', 'ratio7',
        'text8', 'image8', 'ratio8',
        'text9', 'image9', 'ratio9',
        'text10', 'image10', 'ratio10',
        'status', 'fbappid', 'title'
    ];

    public function series() {
        return $this->hasMany(ContentSeries::class);
    }

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }
}
