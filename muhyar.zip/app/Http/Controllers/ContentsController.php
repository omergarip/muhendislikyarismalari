<?php

namespace App\Http\Controllers;

use App\Content;
use App\ContentSeries;
use Analytics;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Spatie\Analytics\Period;

class ContentsController extends Controller
{
    public function index(Request $request)
    {
        $uri = $request->path();
        return view('contents.index')
            ->with('contents', Content::where('status', '=', 'on')->paginate(5))
            ->with('series', ContentSeries::all())
            ->with('uri', $uri);
    }

    public function create()
    {
        return view('contents.create')->with('series', ContentSeries::all());
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'cover' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image1' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image2' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image3' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image4' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image5' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image6' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image7' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image8' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image9' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'image10' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

        $name = Str::slug($request->cover->getClientOriginalName());
        $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
        $filename = $filename . time() . '.' . $request->cover->getClientOriginalExtension();
        $cover = $request->cover->storeAs('storage/contents', $filename);
        $name1 = Str::slug($request->image->getClientOriginalName());
        $filename1 = str_replace(array('jpg','jpeg','png', 'svg'), '',$name1);
        $filename1 = $filename1 . time() . '.' . $request->image->getClientOriginalExtension();
        $image = $request->image->storeAs('storage/contents', $filename1);
        if ($request->hasFile('image1')){
            $name = Str::slug($request->image1->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image1->getClientOriginalExtension();
            $image1 = $request->image1->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image2')){
            $name = Str::slug($request->image2->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image2->getClientOriginalExtension();
            $image2 = $request->image2->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image3')){
            $name = Str::slug($request->image3->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image3->getClientOriginalExtension();
            $image3 = $request->image3->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image4')){
            $name = Str::slug($request->image4->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image4->getClientOriginalExtension();
            $image4 = $request->image4->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image5')){
            $name = Str::slug($request->image5->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image5->getClientOriginalExtension();
            $image5 = $request->image5->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image6')){
            $name = Str::slug($request->image6->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image6->getClientOriginalExtension();
            $image6 = $request->image6->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image7')){
            $name = Str::slug($request->image7->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image7->getClientOriginalExtension();
            $image7 = $request->image7->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image8')){
            $name = Str::slug($request->image8->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image8->getClientOriginalExtension();
            $image8 = $request->image8->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image9')){
            $name = Str::slug($request->image9->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image9->getClientOriginalExtension();
            $image9 = $request->image9->storeAs('storage/contents', $filename);
        }
        if ($request->hasFile('image10')){
            $name = Str::slug($request->image10->getClientOriginalName());
            $filename = str_replace(array('jpg','jpeg','png', 'svg'), '',$name);
            $filename = $filename . time() . '.' . $request->image10->getClientOriginalExtension();
            $image10 = $request->image10->storeAs('storage/contents', $filename);
        }
        Content::create([
            'cover' => $cover,
            'title' => $request->title,
            'page_title' => $request->page_title,
            'user_id' => auth()->id(),
            'series_link' => $request->series_link,
            'text' => $request->text,
            'image' => $image,
            'ratio' => '100%',
            'text1' => $request->text1,
            'image1' => $request->hasFile('image1') ? $image1 : '',
            'ratio1' => '100%',
            'text2' => $request->text2,
            'image2' => $request->hasFile('image2') ? $image2 : '',
            'ratio2' => '100%',
            'text3' => $request->text3,
            'image3' => $request->hasFile('image3') ? $image3 : '',
            'ratio3' => '100%',
            'text4' => $request->text4,
            'image4' => $request->hasFile('image4') ? $image4 : '',
            'ratio4' => '100%',
            'text5' => $request->text5,
            'image5' => $request->hasFile('image5') ? $image5 : '',
            'ratio5' => '100%',
            'text6' => $request->text6,
            'image6' => $request->hasFile('image6') ? $image6 : '',
            'ratio6' => '100%',
            'text7' => $request->text7,
            'image7' => $request->hasFile('image7') ? $image7 : '',
            'ratio7' => '100%',
            'text8' => $request->text8,
            'image8' => $request->hasFile('image8') ? $image8 : '',
            'ratio8' => '100%',
            'text9' => $request->text9,
            'image9' => $request->hasFile('image9') ? $image9 : '',
            'ratio9' => '100%',
            'text10' => $request->text10,
            'image10' => $request->hasFile('image10') ? $image10 : '',
            'ratio10' => '100%',
            'status' => 'off',
            'fbappid' => '2012401338806092',
        ]);

        session()->flash('success', 'Content is created successfully.');
        return redirect(route('contents.index'));
    }

    public function show($link, $slug, Request $request)
    {
        $content = Content::whereSlug($slug)->first();
        $uri = $request->path();
        $url = $request->fullUrl();
        $start_date = Carbon::instance($content->created_at);
        $analyticsData = Analytics::performQuery(
            Period::create($start_date->subDays(1), today()->endOfDay()),
            'ga:pageviews',
            [
                'metrics' => 'ga:pageviews',
                'dimensions' => 'ga:pagePath',
                'filters' => 'ga:pagePath==/'.$uri
            ]
        );

        $pageViews = $analyticsData['totalsForAllResults']['ga:pageviews'];
        return view('contents.show')
            ->with('url', $url)
            ->with('content', $content)
            ->with('pageViews', $pageViews)
            ->with('series', ContentSeries::where('link', '=', $content->series_link)->first());
    }

    public function edit(Content $content)
    {
        return view('posts.create')->with('post', $content)->with('series', ContentSeries::all());
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function series($link, Request $request)
    {
        $uri = $request->path();
        $contents = Content::where('series_link', '=', $link)->paginate(5);
        return view('contents.index', compact('uri'))
            ->with('contents', $contents)
            ->with('series', ContentSeries::all());
    }
}
