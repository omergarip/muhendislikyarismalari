<?php $__env->startSection('meta'); ?>
    <meta property="fb:app_id"        content="<?php echo e($content->fbappid); ?>"/>
    <meta property="og:url"           content="<?php echo e($url); ?>" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="<?php echo e($content->page_title); ?>" />
    <meta property="og:image"         content="<?php echo e(asset('/'.$content->image)); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <title><?php echo e($content->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container u-margin-bottom-big u-margin-top-big"> <!--Container-->
        <div class="content-page"> <!-- Blog Header-->
            <div class="brow" > <!-- Row -->
                <div class="col-sm-10 mx-auto"> <!-- Main Blog Area -->
                    <div class="content-header u-margin-top-big">
                        <div class="content-header__top ">
                            <h1><?php echo e($content->page_title); ?></h1>
                            <div class="content-header__info">
                                <div class="content-header__links">
                                    <a href="<?php echo e(route('home')); ?>">Ana sayfa
                                        <span>&nbsp;>&nbsp;</span>
                                    </a>
                                    <a href="<?php echo e(route('contents.index')); ?>">İçerikler
                                        <span>&nbsp;>&nbsp;</span>
                                    </a>
                                    <a href="<?php echo e(route('contents.index', $series->link)); ?>"><?php echo e($series->series_name); ?></a>
                                </div>
                                <p><?php echo e(date('d.m.Y h:m:s', strtotime($content->created_at))); ?>' te yayınlandı.</p>
                                <?php if($content->created_at != $content->updated_at): ?>
                                    <p><?php echo e(date('d.m.Y h:m:s', strtotime($content->updated_at))); ?>' te düzenlendi.</p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="owner__profile">
                            <img src="<?php echo e(asset('/img/profile.jpeg')); ?>">
                            <h6><strong>Mühendislik Yarışmaları <br><span></span></strong></h6>
                        </div>
                    </div>
                    <section id="social2">
                        <div class="social_panel">
                            <i class="fas fa-share-alt"></i>
                            <div class="shared-count">
                                <span class="number">0</span>
                                <span class="shares">Paylaşım</span>
                            </div>
                            <a class="fb" rel="nofollow" target="_blank"
                               href="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               data-link="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>">
                                <i class="fab fa-facebook-f"></i>
                                <span class="social_share">Paylas</span>
                            </a>

                            <a name="whatsapp" style="background-color: #4dc247;" id="share" class="wp"
                               href="https://api.whatsapp.com/send?text=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" target="_blank">
                                <i class="fab fa-whatsapp"></i>
                                <span class="social_share">Paylas</span>

                            </a>
                            <a style="background-color: #007bb5;" id="share" class="ln"
                               href="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               data-link="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               target="_blank">
                                <i class="fab fa-linkedin"></i>
                                <span class="social_share">Paylas</span>
                            </a>
                            <a style="background-color: #55acee;" id="share" class="tw"
                               href="https://twitter.com/share?original_referer=/&text=&url=
                                            http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" data-link="https://twitter.com/share?original_referer=/&text=&url=
                                            http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" target="_blank">
                                <i class="fab fa-twitter"></i>
                                <span class="social_share">Paylas</span>

                            </a>
                            <div class="page-view">
                                <span class="read_number"><?php echo e($pageViews); ?></span>
                                <span class="read">Okunma</span>
                            </div>
                        </div>
                    </section>
                    <div class="content-page__detail">
                        <?php echo $content->text; ?>

                    </div>
                    <div class="content-page__img mx-auto">
                        <img class="my-2" src="<?php echo e(asset('/'.$content->image)); ?>" alt="<?php echo e($content->title); ?>"/>
                    </div>
                    <?php if($content->text1 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text1; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image1 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image1)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text2 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text2; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image2 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image2)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text3 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text3; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image3 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image3)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text4 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text4; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image4 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image4)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text5 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text5; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image5 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image5)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text6 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text6; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image6 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image6)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text7 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text7; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image7 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image7)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text8 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text8; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image8 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image8)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text9 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text9; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image9 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image9)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <?php if($content->text10 != ''): ?>
                        <div class="content-page__detail">
                            <?php echo $content->text10; ?>

                        </div>
                    <?php endif; ?>
                    <?php if($content->image10 != ''): ?>
                        <div class="content-page__img mx-auto">
                            <img class="img-fluid my-2" src="<?php echo e(asset('/'.$content->image10)); ?>" alt="<?php echo e($content->title); ?>"/>
                        </div>
                    <?php endif; ?>
                    <h1 class="text-center mt-5">
                        <strong>Bilgi paylaştıkça çoğalır. Çevrenizdeki mühendisler ile içeriği paylaşarak bize destek olabilirsiniz.</strong>
                    </h1>


                    <section id="social2">
                        <div class="social_panel">
                            <a class="fb" rel="nofollow" target="_blank"
                               href="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               data-link="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>">
                                <i class="fab fa-facebook-f"></i>
                                <span class="social_share">Paylas</span>
                            </a>

                            <a name="whatsapp" style="background-color: #4dc247;" id="share" class="wp"
                               href="https://api.whatsapp.com/send?text=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" target="_blank">
                                <i class="fab fa-whatsapp"></i>
                                <span class="social_share">Paylas</span>

                            </a>
                            <a style="background-color: #007bb5;" id="share" class="ln"
                               href="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               data-link="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>"
                               target="_blank">
                                <i class="fab fa-linkedin"></i>
                                <span class="social_share">Paylas</span>
                            </a>
                            <a style="background-color: #55acee;" id="share" class="tw"
                               href="https://twitter.com/share?original_referer=/&text=&url=
                                            http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" data-link="https://twitter.com/share?original_referer=/&text=&url=
                                            http://www.muhendislikyarismalari.com/icerik/<?php echo e($content->series_link); ?>/<?php echo e($content->slug); ?>" target="_blank">
                                <i class="fab fa-twitter"></i>
                                <span class="social_share">Paylas</span>

                            </a>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Google Analytics -->
    <script>
        window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
        ga('create', 'UA-XXXXX-Y', 'auto');
        ga('send', 'pageview');
    </script>
    <script async src='https://www.google-analytics.com/analytics.js'></script><!-- Google Analytics -->
    <script>
        window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
        ga('create', 'UA-131523931-1', 'auto');
        ga('send', 'pageview');
    </script>
    <script async src='https://www.google-analytics.com/analytics.js'></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\muhyar\resources\views/contents/show.blade.php ENDPATH**/ ?>