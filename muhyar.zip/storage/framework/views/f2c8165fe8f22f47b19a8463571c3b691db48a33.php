<?php $__env->startSection('contents'); ?>

    <div class="d-flex justify-content-end mb-2">
        <a href="<?php echo e(route('series.create')); ?>" class="btn btn-success">Kategori Ekle</a>
    </div>

    <div class="card card-default">
        <div class="card-header">
            <div class="card-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Kategori Adı</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cseries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cseries->series_name); ?></td>

                            <td>
                                <form action="<?php echo e(route('series.destroy', $cseries->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <div class="text-center">
        <?php echo e($series->links()); ?>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\muhyar\resources\views/series/index.blade.php ENDPATH**/ ?>