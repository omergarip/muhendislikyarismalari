<?php $__env->startSection('title'); ?>
    <title>Mühendislik Yarışmaları</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <main>
        <section class="section-competitions js--section-competitions" id="competitions">
            <?php if($competitions->count() > 0): ?>
                <div class="u-center-text u-margin-bottom-big">
                    <h2 class="heading-secondary">
                        YARIŞMALAR
                    </h2>
                </div>
                <div class="js--wp-1">
                    <div class="row mx-auto u-margin-bottom-big">
                        <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 d-flex justify-content-around align-items-center">
                            <figure class="competitions">
                                <div class="competitions__hero">
                                    <a href="<?php echo e(route('competitions.show', $competition->slug)); ?>">
                                        <img src="<?php echo e(asset('/public/img/'.$competition->image)); ?>" alt="<?php echo e($competition->title); ?>" class="competitions__img">
                                    </a>
                                </div>
                                <div class="competitions__content">
                                    <div class="competitions__title">
                                        <h1 class="competitions__heading u-center-text"><?php echo e($competition->title); ?> </h1>
                                        <div class="tags competitions__tag">Yarışma</div>
                                    </div>

                                    <ul class="competitions__description">
                                        <li>
                                            <span class="label u-bold-text">Kurum:</span>
                                            <span><?php echo e($competition->organizer); ?></span>
                                        </li>
                                        <li>
                                            <span class="label u-bold-text">Son Basvuru Tarihi:</span>
                                            <span><?php echo e(date('d.m.Y', strtotime($competition->deadline))); ?></span>
                                        </li>
                                    </ul>
                                    <div class="competitions__details">
                                        <a class="bttn bttn--competition" href="<?php echo e(route('competitions.show', $competition->slug)); ?>">Detaylı İncele</a>
                                    </div>
                                </div>

                                <div class="social__buttons competitions__social">
                                    <a class="fb" rel="nofollow" target="_blank"
                                       href="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>"
                                       data-link="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>">
                                        <i class="fab fa-facebook-f"></i><span></span>
                                    </a>
                                    <a id="share" class="tw" href="https://twitter.com/share?original_referer=/&text=&url=
                                        http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>" data-link="https://twitter.com/share?original_referer=/&text=&url=
                                        http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>" target="_blank">
                                        <i class="fab fa-twitter"></i><span></span>
                                    </a>
                                    <a id="share" class="ln"
                                       href="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>"
                                       data-link="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>"
                                       target="_blank">
                                        <i class="fab fa-linkedin"></i><span></span>
                                    </a>
                                    <a name="whatsapp" id="share" class="wp"
                                       href="https://api.whatsapp.com/send?text=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($competition->slug); ?>" target="_blank">
                                        <i class="fab fa-whatsapp"></i><span></span>
                                    </a>
                                </div>
                            </figure>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="u-center-text u-margin-top-big">
                        <a class="bttn bttn--green" href="/yarismalar.html">DAHA FAZLA GÖR</a>
                    </div>

                </div>
            <?php endif; ?>
        </section>
        <section class="section-contents">
            <div class="u-center-text u-margin-bottom-big">
                <h2 class="heading-content">
                    İÇERİKLER
                </h2>
            </div>
            <?php if($contents->count() > 3): ?>
            <div class="container text-center mt-5">
                <div class="row mx-auto my-auto js--wp-2">
                    <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner w-100" role="listbox">
                            <div class="carousel-item active">
                                <div class="col-lg-4 col-md-6">
                                    <a href="<?php echo e(route('contents.link', $first_content[0]->link)); ?>">
                                        <img class="img-fluid" src="<?php echo e(asset('/storage/'.$first_content[0]->cover)); ?>">
                                    </a>
                                </div>
                            </div>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item">
                                    <div class="col-lg-4 col-md-6">
                                        <a href="<?php echo e(route('contents.show', [$content->series_link, $content->slug])); ?>">
                                            <img class="img-fluid" src="<?php echo e(asset('/storage/'.$content->cover)); ?>">
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <a class="carousel-control-prev bg-dark w-auto" href="#myCarousel2" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next bg-dark w-auto" href="#myCarousel2" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="row mx-auto">
                    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mx-auto ">
                            <div>
                                <figure class="contents mx-auto">
                                    <a href="<?php echo e(route('contents.show', [$content->series_id, $content->slug])); ?>">
                                        <img src="<?php echo e(asset('/storage/'.$content->cover)); ?>" class="img-fluid" alt="<?php echo e($content->title); ?>">
                                    </a>
                                </figure>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <div class="u-center-text u-margin-top-huge">
                <a href="#" class="btn-text">İçeriklere Göz At &rarr;</a>
            </div>
        </section>

        <section class="section-announcements">
            <div class="u-center-text u-margin-bottom-big">
                <h2 class="heading-secondary">
                    DUYURULAR
                </h2>
            </div>

            <div class="js--wp-3">
                <div class="row mx-auto u-margin-bottom-big">
                    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 d-flex justify-content-around align-items-center">
                            <figure class="competitions">
                                <div class="competitions__hero">
                                    <a href="<?php echo e(route('announcements.show', [$announcement->category_slug, $announcement->slug])); ?>">
                                        <img src="<?php echo e(asset('/'.$announcement->image)); ?>" alt="<?php echo e($announcement->title); ?>" class="competitions__img">
                                    </a>
                                </div>
                                <div class="competitions__content">
                                    <div class="competitions__title">
                                        <h1 class="competitions__heading u-center-text"><?php echo e($announcement->title); ?> </h1>
                                        <div class="tags <?php echo e($announcement->category_slug); ?>__tag"><?php echo e($announcement->category_slug); ?></div>
                                    </div>
                                    <?php if($announcement->category_slug == 'haber' || $announcement->category_slug == 'derece'): ?>
                                        <ul class="competitions__description">
                                            <li>
                                                <span><?php echo e(\Illuminate\Support\Str::limit($announcement->description, 250, $end='...')); ?></span>
                                            </li>
                                        </ul>
                                    <?php else: ?>
                                        <ul class="competitions__description">
                                            <li>
                                                <span class="label u-bold-text">Kurum:</span>
                                                <span><?php echo e($announcement->organizer); ?></span>
                                            </li>
                                            <li>
                                                <span class="label u-bold-text">Son Basvuru Tarihi:</span>
                                                <span><?php echo e(date('d.m.Y', strtotime($announcement->deadline))); ?></span>
                                            </li>
                                        </ul>
                                    <?php endif; ?>
                                    <div class="competitions__details">
                                        <a class="bttn bttn--<?php echo e($announcement->category_slug); ?>" href="<?php echo e(route('announcements.show', [$announcement->category_slug, $announcement->slug])); ?>">Detaylı İncele</a>
                                    </div>
                                </div>

                                <div class="social__buttons announcements__social-<?php echo e($announcement->category_slug); ?>">
                                    <a class="fb" rel="nofollow" target="_blank"
                                       href="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>"
                                       data-link="https://www.facebook.com/share.php?u=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>">
                                        <i class="fab fa-facebook-f"></i><span></span>
                                    </a>
                                    <a id="share" class="tw" href="https://twitter.com/share?original_referer=/&text=&url=
                                        http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>" data-link="https://twitter.com/share?original_referer=/&text=&url=
                                        http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>" target="_blank">
                                        <i class="fab fa-twitter"></i><span></span>
                                    </a>
                                    <a id="share" class="ln"
                                       href="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>"
                                       data-link="https://www.linkedin.com/cws/share?url=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>"
                                       target="_blank">
                                        <i class="fab fa-linkedin"></i><span></span>
                                    </a>
                                    <a name="whatsapp" id="share" class="wp"
                                       href="https://api.whatsapp.com/send?text=http://www.muhendislikyarismalari.com/yarisma/<?php echo e($announcement->slug); ?>" target="_blank">
                                        <i class="fab fa-whatsapp"></i><span></span>
                                    </a>
                                </div>
                            </figure>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="u-center-text u-margin-top-big">
                    <a class="bttn bttn--green" href="<?php echo e(route('announcements.index')); ?>">DAHA FAZLA GÖR</a>
                </div>
        </section>
    </main>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\muhyar\resources\views/index.blade.php ENDPATH**/ ?>