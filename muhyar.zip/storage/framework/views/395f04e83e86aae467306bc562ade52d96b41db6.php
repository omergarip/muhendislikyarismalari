<header class="header"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <nav>
        <div class="row">
            <a href="<?php echo e(route('home')); ?>" style="margin-right: auto;">
                <img src="<?php echo e(url('img/favicon.png')); ?>" alt="Mühendislik Yarışmaları" class="header__logo">
            </a>
            <ul class="main-nav js--main-nav">
                <li><a class="mainlink" href="<?php echo e(route('competitions.index')); ?>">Yarışmalar</a></li>
                <li><a class="mainlink" href="<?php echo e(route('contents.index')); ?>">İçerikler</a></li>
                <li><a class="mainlink" href="<?php echo e(route('announcements.index')); ?>">Duyurular</a></li>
            </ul>
            <a class="mobile-nav-icon js--nav-icon"><i class="icon fas fa-bars"></i></a>
        </div>
    </nav>
    <div class="container text-center content--carousel">
        <div class="row mx-auto my-auto">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <div class="col-lg-4 col-md-6">
                            <a href="<?php echo e(route('contents.link', $first[0]->link)); ?>">
                                <img class="img-fluid" src="<?php echo e(URL::asset($first[0]->cover)); ?>" alt="$first[0]->series_name">
                            </a>
                        </div>
                    </div>
                        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <div class="col-lg-4 col-md-6">
                                    <a href="<?php echo e(route('contents.link', $item->link)); ?>">
                                        <img class="img-fluid" src="<?php echo e(URL::asset($item->cover)); ?>" alt="<?php echo e($item->series_name); ?>">
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <a class="carousel-control-prev bg-dark w-auto" style="height: 98.4%;" href="#myCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next bg-dark w-auto" style="height: 98.2%;" href="#myCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\xampp\htdocs\muhyar\resources\views/includes/header.blade.php ENDPATH**/ ?>