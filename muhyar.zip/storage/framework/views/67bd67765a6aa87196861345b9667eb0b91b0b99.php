<?php $__env->startSection('title'); ?>
    <title>İçerikler</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content" style="background-color: #f5f5f5;">
        <div class="content-navigation">
            <input type="checkbox" class="navigation__checkbox" id="navi-toggle">

            <label for="navi-toggle" class="navigation__button">
                <span class="navigation__icon">&nbsp;</span>
            </label>

            <div class="navigation__background">&nbsp;</div>

            <nav class="navigation__nav">
                <ul class="content-navigation__list">
                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cseries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="content-navigation__item">
                            <a class="navigation__link <?php echo e($uri == 'icerikler/'.$cseries->link ? 'active' : ''); ?>"
                               href="<?php echo e(route('contents.link', $cseries->link)); ?>" >
                                <?php echo e($cseries->series_name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </nav>
        </div>
        <main>
            <section class="section-content" id="content-page">

                <div id="wrapper">
                    <div id="content-sidebar-wrapper">
                        <aside id="sidebar">
                            <ul id="sidemenu" class="sidebar-nav">
                                <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cseries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a class="<?php echo e($uri == 'icerikler/'.$cseries->link ? 'active' : ''); ?>"
                                           href="<?php echo e(route('contents.link', $cseries->link)); ?>" >
                                            <span class="sidebar-title "><?php echo e($cseries->series_name); ?></span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </aside>
                    </div>
                    <main id="page-content-wrapper" role="main">
                        <div class="row mx-auto">
                            <div class="u-center-text u-margin-bottom-medium u-margin-top-huge w-100">
                                <h2 class="heading-secondary">
                                    İÇERİKLER
                                </h2>
                            </div>
                            <?php if($contents->count() > 0): ?>
                                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6 mx-auto ">
                                        <div>
                                            <figure class="contents mx-auto">
                                                <a href="<?php echo e(route('contents.show', [$content->series_link, $content->slug])); ?>">
                                                    <img src="<?php echo e(asset('/'.$content->cover)); ?>" class="img-fluid" alt="<?php echo e($content->title); ?>">
                                                </a>
                                            </figure>
                                        </div> <!-- End of the list  -->
                                    </div> <!-- End of the col-lg-6  -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="card card-default mx-auto mb-auto">
                                    <div class="card-body">
                                        <h3>Bu içerik serisi altında henüz paylaşım yapılmadı. Lütfen daha sonra tekrar kontrol ediniz</h3>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div> <!-- End of the row  -->
                    </main>
                </div>



            </section>
        </main>
        <div class="text-center">
            <?php echo e($contents->links()); ?>

        </div>
    </div>


    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\muhyar\resources\views/contents/index.blade.php ENDPATH**/ ?>