export * from './OverlayScrollbarsPlugin';
export * from './OverlayScrollbarsComponent';
export { default as OverlayScrollbarsComponent } from './OverlayScrollbarsComponent.vue';